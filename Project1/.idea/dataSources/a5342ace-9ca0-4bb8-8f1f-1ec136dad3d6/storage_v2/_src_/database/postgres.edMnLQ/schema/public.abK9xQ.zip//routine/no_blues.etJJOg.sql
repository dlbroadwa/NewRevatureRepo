create function no_blues() returns trigger
    language plpgsql
as
$$
begin 
		if (TG_OP = 'INSERT') then 
			if (UPPER(new.color) = 'BLUE') then 
				return null;
			end if;
		end if;
		
		if (UPPER(new.color) = 'BLUE') then
			return old;
		end if;
		return new;
	end

$$;

alter function no_blues() owner to nathan;

